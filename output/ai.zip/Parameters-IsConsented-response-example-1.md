# IsConsented-response-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "IsConsented-response-example-1",
  "parameter" : [
    {
      "name" : "consented",
      "valueBoolean" : true
    }
  ]
}

```
