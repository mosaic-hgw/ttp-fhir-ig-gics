# Consent Policy Reference - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ConsentPolicyReference",
  "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ConsentPolicyReference",
  "version" : "2025.2.0",
  "name" : "ConsentPolicyReference",
  "title" : "Consent Policy Reference",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-06-12",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [
    {
      "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.ths-greifswald.de/"
        }
      ]
    }
  ],
  "description" : "Referenz auf eine Consent Policy zur Verwendung innerhalb eines Consent Moduls",
  "copyright" : "Copyright 2020-2025 Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    }
  ],
  "kind" : "complex-type",
  "abstract" : false,
  "context" : [
    {
      "type" : "element",
      "expression" : "Questionnaire"
    },
    {
      "type" : "element",
      "expression" : "Questionnaire.item"
    }
  ],
  "type" : "Extension",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Extension",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "Extension",
        "path" : "Extension",
        "short" : "Consent Policy Reference",
        "definition" : "Referenz auf eine Consent Policy zur Verwendung innerhalb eines Consent Moduls"
      },
      {
        "id" : "Extension.extension",
        "path" : "Extension.extension",
        "min" : 1
      },
      {
        "id" : "Extension.extension:reference",
        "path" : "Extension.extension",
        "sliceName" : "reference",
        "min" : 1,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:reference.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:reference.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "reference"
      },
      {
        "id" : "Extension.extension:reference.value[x]",
        "path" : "Extension.extension.value[x]",
        "min" : 1,
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "https://ths-greifswald.de/fhir/StructureDefinition/gics/ActivityDefinition/ConsentPolicy"
            ]
          }
        ]
      },
      {
        "id" : "Extension.extension:reference.value[x].reference",
        "path" : "Extension.extension.value[x].reference",
        "min" : 1
      },
      {
        "id" : "Extension.extension:comment",
        "path" : "Extension.extension",
        "sliceName" : "comment",
        "min" : 0,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:comment.extension",
        "path" : "Extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:comment.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "comment"
      },
      {
        "id" : "Extension.extension:comment.value[x]",
        "path" : "Extension.extension.value[x]",
        "min" : 1,
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Extension.extension:externalProperty",
        "path" : "Extension.extension",
        "sliceName" : "externalProperty",
        "min" : 0,
        "max" : "*"
      },
      {
        "id" : "Extension.extension:externalProperty.extension",
        "path" : "Extension.extension.extension",
        "min" : 2
      },
      {
        "id" : "Extension.extension:externalProperty.extension:key",
        "path" : "Extension.extension.extension",
        "sliceName" : "key",
        "min" : 1,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:externalProperty.extension:key.extension",
        "path" : "Extension.extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:externalProperty.extension:key.url",
        "path" : "Extension.extension.extension.url",
        "fixedUri" : "key"
      },
      {
        "id" : "Extension.extension:externalProperty.extension:key.value[x]",
        "path" : "Extension.extension.extension.value[x]",
        "min" : 1,
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Extension.extension:externalProperty.extension:value",
        "path" : "Extension.extension.extension",
        "sliceName" : "value",
        "min" : 1,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:externalProperty.extension:value.extension",
        "path" : "Extension.extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:externalProperty.extension:value.url",
        "path" : "Extension.extension.extension.url",
        "fixedUri" : "value"
      },
      {
        "id" : "Extension.extension:externalProperty.extension:value.value[x]",
        "path" : "Extension.extension.extension.value[x]",
        "min" : 1,
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Extension.extension:externalProperty.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "externalProperty"
      },
      {
        "id" : "Extension.extension:externalProperty.value[x]",
        "path" : "Extension.extension.value[x]",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:expirationProperty",
        "path" : "Extension.extension",
        "sliceName" : "expirationProperty",
        "min" : 0,
        "max" : "*"
      },
      {
        "id" : "Extension.extension:expirationProperty.extension",
        "path" : "Extension.extension.extension",
        "min" : 2
      },
      {
        "id" : "Extension.extension:expirationProperty.extension:key",
        "path" : "Extension.extension.extension",
        "sliceName" : "key",
        "min" : 1,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:expirationProperty.extension:key.extension",
        "path" : "Extension.extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:expirationProperty.extension:key.url",
        "path" : "Extension.extension.extension.url",
        "fixedUri" : "key"
      },
      {
        "id" : "Extension.extension:expirationProperty.extension:key.value[x]",
        "path" : "Extension.extension.extension.value[x]",
        "min" : 1,
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Extension.extension:expirationProperty.extension:value",
        "path" : "Extension.extension.extension",
        "sliceName" : "value",
        "min" : 1,
        "max" : "1"
      },
      {
        "id" : "Extension.extension:expirationProperty.extension:value.extension",
        "path" : "Extension.extension.extension.extension",
        "max" : "0"
      },
      {
        "id" : "Extension.extension:expirationProperty.extension:value.url",
        "path" : "Extension.extension.extension.url",
        "fixedUri" : "value"
      },
      {
        "id" : "Extension.extension:expirationProperty.extension:value.value[x]",
        "path" : "Extension.extension.extension.value[x]",
        "min" : 1,
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Extension.extension:expirationProperty.url",
        "path" : "Extension.extension.url",
        "fixedUri" : "expirationProperty"
      },
      {
        "id" : "Extension.extension:expirationProperty.value[x]",
        "path" : "Extension.extension.value[x]",
        "max" : "0"
      },
      {
        "id" : "Extension.url",
        "path" : "Extension.url",
        "fixedUri" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ConsentPolicyReference"
      },
      {
        "id" : "Extension.value[x]",
        "path" : "Extension.value[x]",
        "max" : "0"
      }
    ]
  }
}

```
