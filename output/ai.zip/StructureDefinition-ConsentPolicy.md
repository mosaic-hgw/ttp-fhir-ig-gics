# ConsentPolicy - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ConsentPolicy",
  "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ActivityDefinition/ConsentPolicy",
  "version" : "2025.2.0",
  "name" : "ConsentPolicy",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-06-12",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [
    {
      "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.ths-greifswald.de/"
        }
      ]
    }
  ],
  "description" : "Abbildung aller relevanten Information zur Verwaltung wiederverwendbarer Einwilligungspolicies mit gICS",
  "copyright" : "Copyright 2020-2025 Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "workflow",
      "uri" : "http://hl7.org/fhir/workflow",
      "name" : "Workflow Pattern"
    },
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    },
    {
      "identity" : "w5",
      "uri" : "http://hl7.org/fhir/fivews",
      "name" : "FiveWs Pattern Mapping"
    },
    {
      "identity" : "objimpl",
      "uri" : "http://hl7.org/fhir/object-implementation",
      "name" : "Object Implementation Information"
    }
  ],
  "kind" : "resource",
  "abstract" : false,
  "type" : "ActivityDefinition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/ActivityDefinition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [
      {
        "id" : "ActivityDefinition",
        "path" : "ActivityDefinition",
        "short" : "Consent Policy",
        "definition" : "Atomare Aussage zu der eine Person seine Einwilligung erteilen kann"
      },
      {
        "id" : "ActivityDefinition.meta",
        "path" : "ActivityDefinition.meta",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.meta.lastUpdated",
        "path" : "ActivityDefinition.meta.lastUpdated",
        "short" : "updateDate",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.extension:created",
        "path" : "ActivityDefinition.extension",
        "sliceName" : "created",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "https://ths-greifswald.de/fhir/StructureDefinition/gics/Created"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.extension:externalProperty",
        "path" : "ActivityDefinition.extension",
        "sliceName" : "externalProperty",
        "label" : "externalProperties",
        "short" : "externalProperties",
        "definition" : "Liste frei konfigurierbarer external Properties nach dem KeyValuePrinzip zur Auswertung durch externe Anwendersysteme",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Extension",
            "profile" : [
              "https://ths-greifswald.de/fhir/StructureDefinition/gics/ExternalProperty"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.extension:externalProperty.extension:key",
        "path" : "ActivityDefinition.extension.extension",
        "sliceName" : "key"
      },
      {
        "id" : "ActivityDefinition.extension:externalProperty.extension:key.value[x]",
        "path" : "ActivityDefinition.extension.extension.value[x]",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.extension:externalProperty.extension:value",
        "path" : "ActivityDefinition.extension.extension",
        "sliceName" : "value"
      },
      {
        "id" : "ActivityDefinition.extension:externalProperty.extension:value.value[x]",
        "path" : "ActivityDefinition.extension.extension.value[x]",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.url",
        "path" : "ActivityDefinition.url",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.identifier",
        "path" : "ActivityDefinition.identifier",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.version",
        "path" : "ActivityDefinition.version",
        "label" : "version",
        "short" : "version",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.name",
        "path" : "ActivityDefinition.name",
        "short" : "name",
        "definition" : "Name der ConsentPolicy (computer friendly)",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.title",
        "path" : "ActivityDefinition.title",
        "short" : "label",
        "definition" : "Bezeichnung (human friendly)",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.subtitle",
        "path" : "ActivityDefinition.subtitle",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.status",
        "path" : "ActivityDefinition.status",
        "short" : "finalisiert ja/nein",
        "definition" : "Bearbeitungsstatus:\r\ngICS-Äquivalente:\r\nfinalized=true => active\r\nfinalized=false => draft",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.experimental",
        "path" : "ActivityDefinition.experimental",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.subject[x]",
        "path" : "ActivityDefinition.subject[x]",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.date",
        "path" : "ActivityDefinition.date",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.publisher",
        "path" : "ActivityDefinition.publisher",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.contact",
        "path" : "ActivityDefinition.contact",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.description",
        "path" : "ActivityDefinition.description",
        "short" : "comment",
        "definition" : "administrative comment",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.useContext",
        "path" : "ActivityDefinition.useContext",
        "short" : "domainName",
        "definition" : "Verweis auf die Domäne",
        "min" : 1,
        "max" : "1",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.useContext.code",
        "path" : "ActivityDefinition.useContext.code",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.useContext.code.system",
        "path" : "ActivityDefinition.useContext.code.system",
        "min" : 1,
        "fixedUri" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.useContext.code.code",
        "path" : "ActivityDefinition.useContext.code.code",
        "min" : 1,
        "fixedCode" : "program",
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.useContext.value[x]",
        "path" : "ActivityDefinition.useContext.value[x]",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "https://ths-greifswald.de/fhir/gics/StructureDefinition/ConsentDomain"
            ]
          }
        ],
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.useContext.value[x].reference",
        "path" : "ActivityDefinition.useContext.value[x].reference",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.jurisdiction",
        "path" : "ActivityDefinition.jurisdiction",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.purpose",
        "path" : "ActivityDefinition.purpose",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.usage",
        "path" : "ActivityDefinition.usage",
        "short" : "comment",
        "definition" : "administrative comment",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.copyright",
        "path" : "ActivityDefinition.copyright",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.approvalDate",
        "path" : "ActivityDefinition.approvalDate",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.lastReviewDate",
        "path" : "ActivityDefinition.lastReviewDate",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.effectivePeriod",
        "path" : "ActivityDefinition.effectivePeriod",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.topic",
        "path" : "ActivityDefinition.topic",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.author",
        "path" : "ActivityDefinition.author",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.editor",
        "path" : "ActivityDefinition.editor",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.reviewer",
        "path" : "ActivityDefinition.reviewer",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.endorser",
        "path" : "ActivityDefinition.endorser",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.relatedArtifact",
        "path" : "ActivityDefinition.relatedArtifact",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.library",
        "path" : "ActivityDefinition.library",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.kind",
        "path" : "ActivityDefinition.kind",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.profile",
        "path" : "ActivityDefinition.profile",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.code",
        "path" : "ActivityDefinition.code",
        "min" : 1,
        "mustSupport" : true,
        "binding" : {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-bindingName",
              "valueString" : "ActivityDefinitionType"
            }
          ],
          "strength" : "extensible",
          "valueSet" : "https://ths-greifswald.de/fhir/ValueSet/gics/Policy"
        }
      },
      {
        "id" : "ActivityDefinition.code.coding",
        "path" : "ActivityDefinition.code.coding",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.code.coding.system",
        "path" : "ActivityDefinition.code.coding.system",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.code.coding.code",
        "path" : "ActivityDefinition.code.coding.code",
        "min" : 1,
        "mustSupport" : true
      },
      {
        "id" : "ActivityDefinition.intent",
        "path" : "ActivityDefinition.intent",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.priority",
        "path" : "ActivityDefinition.priority",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.doNotPerform",
        "path" : "ActivityDefinition.doNotPerform",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.timing[x]",
        "path" : "ActivityDefinition.timing[x]",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.location",
        "path" : "ActivityDefinition.location",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.participant",
        "path" : "ActivityDefinition.participant",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.product[x]",
        "path" : "ActivityDefinition.product[x]",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.quantity",
        "path" : "ActivityDefinition.quantity",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.dosage",
        "path" : "ActivityDefinition.dosage",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.bodySite",
        "path" : "ActivityDefinition.bodySite",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.specimenRequirement",
        "path" : "ActivityDefinition.specimenRequirement",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.observationRequirement",
        "path" : "ActivityDefinition.observationRequirement",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.observationResultRequirement",
        "path" : "ActivityDefinition.observationResultRequirement",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.transform",
        "path" : "ActivityDefinition.transform",
        "max" : "0"
      },
      {
        "id" : "ActivityDefinition.dynamicValue",
        "path" : "ActivityDefinition.dynamicValue",
        "max" : "0"
      }
    ]
  }
}

```
