# AllConsentsForTemplate-request-example-1 - v2025.1.0



## Resource Content

```json
{
  "resourceType" : "Parameters",
  "id" : "AllConsentsForTemplate-request-example-1",
  "parameter" : [
    {
      "name" : "template",
      "valueString" : "MII;Patienteneinwilligung MII;1.6.f"
    },
    {
      "name" : "domain",
      "valueString" : "MII"
    }
  ]
}

```
