# Consent Quality Control - v2026.1.0

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.1.0 - ci-build  

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Consent Quality Control**

## Resource Profile: Consent Quality Control 

| | |
| :--- | :--- |
| *Official URL*:https://ths-greifswald.de/fhir/StructureDefinition/gics/VerificationResult/ConsentQualityControl | *Version*:2026.1.0 |
| Active as of 2025-06-12 | *Computable Name*:ConsentQualityControl |
| **Copyright/Legal**: Copyright 2020-2025 Unabhängige Treuhandstelle der Universitätsmedizin Greifswald | |

 
Dokumentation des Status der Qualitätsprüfung einer ausgefüllten Einwilligung (QuestionnaireResponse) 

## Suchparameter

Für dieses Profil sind keine Suchparameter definiert.

**Usages:**

* Examples for this Profile: [VerificationResult/ConsentQualityControl-example-1](VerificationResult-ConsentQualityControl-example-1.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ths-greifswald.ttp-fhir-gw.gics|current/StructureDefinition/StructureDefinition-ConsentQualityControl.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-ConsentQualityControl.csv), [Excel](StructureDefinition-ConsentQualityControl.xlsx), [Schematron](StructureDefinition-ConsentQualityControl.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "ConsentQualityControl",
  "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/VerificationResult/ConsentQualityControl",
  "version" : "2026.1.0",
  "name" : "ConsentQualityControl",
  "title" : "Consent Quality Control",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-06-12",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [{
    "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ths-greifswald.de/"
    }]
  }],
  "description" : "Dokumentation des Status der Qualitätsprüfung einer ausgefüllten Einwilligung (QuestionnaireResponse)",
  "copyright" : "Copyright 2020-2025 Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "VerificationResult",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/VerificationResult",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "VerificationResult",
      "path" : "VerificationResult"
    },
    {
      "id" : "VerificationResult.meta.extension:created",
      "path" : "VerificationResult.meta.extension",
      "sliceName" : "created",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/gics/Created"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.extension:comment",
      "path" : "VerificationResult.extension",
      "sliceName" : "comment",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/gics/Comment"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.extension:comment.value[x]",
      "path" : "VerificationResult.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.extension:externalProperty",
      "path" : "VerificationResult.extension",
      "sliceName" : "externalProperty",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/gics/ExternalProperty"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.target",
      "path" : "VerificationResult.target",
      "label" : "validierte Consent-Ressource(n)",
      "short" : "Referenz zu validierte Consent-Ressource(n)",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://fhir.de/ConsentManagement/StructureDefinition/QuestionnaireResponse"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.target.reference",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      }],
      "path" : "VerificationResult.target.reference",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.status",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      }],
      "path" : "VerificationResult.status",
      "label" : "QC-Status",
      "short" : "QC-Status",
      "comment" : "Aktuell werden nur die Statuswerte \"validated\" und \"val-fail\" betrachtet.",
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.statusDate",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      }],
      "path" : "VerificationResult.statusDate",
      "short" : "Datum der QC",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.validationType",
      "path" : "VerificationResult.validationType",
      "short" : "Typ der Qualitätskontrolle",
      "comment" : "Wird hier als Freitext übermittelt.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.validationType.text",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-translatable",
        "valueBoolean" : true
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      }],
      "path" : "VerificationResult.validationType.text",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.attestation",
      "path" : "VerificationResult.attestation",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.attestation.who",
      "path" : "VerificationResult.attestation.who",
      "short" : "qualitätskontrollierende Person",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "VerificationResult.attestation.who.display",
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/elementdefinition-translatable",
        "valueBoolean" : true
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
        "valueCode" : "normative"
      }],
      "path" : "VerificationResult.attestation.who.display",
      "min" : 1,
      "mustSupport" : true
    }]
  }
}

```
