# AllPolicyStatesForPerson-response-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "AllPolicyStatesForPerson-response-example-1",
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "urn:uuid:c52ebb8f-3ca0-4978-9116-22c92aaccb18",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "c52ebb8f-3ca0-4978-9116-22c92aaccb18",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_c52ebb8f-3ca0-4978-9116-22c92aaccb18\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent c52ebb8f-3ca0-4978-9116-22c92aaccb18</b></p><a name=\"c52ebb8f-3ca0-4978-9116-22c92aaccb18\"> </a><a name=\"hcc52ebb8f-3ca0-4978-9116-22c92aaccb18\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_bereitstellen_EU_DSGVO_NIVEAU}\">Herausgabe identifizierender Daten (IDAT) an verantwortliche Stelle zur weiteren Verarbeitung</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_bereitstellen_EU_DSGVO_NIVEAU}\">Herausgabe identifizierender Daten (IDAT) an verantwortliche Stelle zur weiteren Verarbeitung</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.5}\">IDAT bereitstellen EU DSGVO NIVEAU</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "IDAT_bereitstellen_EU_DSGVO_NIVEAU",
              "display" : "Herausgabe identifizierender Daten (IDAT) an verantwortliche Stelle zur weiteren Verarbeitung"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "IDAT_bereitstellen_EU_DSGVO_NIVEAU",
                  "display" : "Herausgabe identifizierender Daten (IDAT) an verantwortliche Stelle zur weiteren Verarbeitung"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.5"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:68148751-1a10-4e5a-84cd-2290950c3793",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "68148751-1a10-4e5a-84cd-2290950c3793",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_68148751-1a10-4e5a-84cd-2290950c3793\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 68148751-1a10-4e5a-84cd-2290950c3793</b></p><a name=\"68148751-1a10-4e5a-84cd-2290950c3793\"> </a><a name=\"hc68148751-1a10-4e5a-84cd-2290950c3793\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_erheben}\">Erfassung neuer identifizierender Daten (IDAT)</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_erheben}\">Erfassung neuer identifizierender Daten (IDAT)</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.2}\">IDAT erheben</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "IDAT_erheben",
              "display" : "Erfassung neuer identifizierender Daten (IDAT)"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "IDAT_erheben",
                  "display" : "Erfassung neuer identifizierender Daten (IDAT)"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.2"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:32fa19b1-f6fb-4fd5-b199-4d4dceb69e53",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "32fa19b1-f6fb-4fd5-b199-4d4dceb69e53",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_32fa19b1-f6fb-4fd5-b199-4d4dceb69e53\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 32fa19b1-f6fb-4fd5-b199-4d4dceb69e53</b></p><a name=\"32fa19b1-f6fb-4fd5-b199-4d4dceb69e53\"> </a><a name=\"hc32fa19b1-f6fb-4fd5-b199-4d4dceb69e53\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_speichern_verarbeiten}\">Speicherung und Verarbeitung identifizierender Daten (IDAT) in der verantwortlichen Stelle</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_speichern_verarbeiten}\">Speicherung und Verarbeitung identifizierender Daten (IDAT) in der verantwortlichen Stelle</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.3}\">IDAT speichern, verarbeiten</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "IDAT_speichern_verarbeiten",
              "display" : "Speicherung und Verarbeitung identifizierender Daten (IDAT) in der verantwortlichen Stelle"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "IDAT_speichern_verarbeiten",
                  "display" : "Speicherung und Verarbeitung identifizierender Daten (IDAT) in der verantwortlichen Stelle"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.3"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:343a8482-a00f-4ae4-974b-884932bdf44a",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "343a8482-a00f-4ae4-974b-884932bdf44a",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_343a8482-a00f-4ae4-974b-884932bdf44a\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 343a8482-a00f-4ae4-974b-884932bdf44a</b></p><a name=\"343a8482-a00f-4ae4-974b-884932bdf44a\"> </a><a name=\"hc343a8482-a00f-4ae4-974b-884932bdf44a\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_zusammenfuehren_Dritte}\">Zusammenführung identifizierender Daten (IDAT) mit Dritten Forschungspartnern</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_zusammenfuehren_Dritte}\">Zusammenführung identifizierender Daten (IDAT) mit Dritten Forschungspartnern</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.4}\">IDAT zusammenfuehren Dritte</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "IDAT_zusammenfuehren_Dritte",
              "display" : "Zusammenführung identifizierender Daten (IDAT) mit Dritten Forschungspartnern"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "IDAT_zusammenfuehren_Dritte",
                  "display" : "Zusammenführung identifizierender Daten (IDAT) mit Dritten Forschungspartnern"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.4"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:f250a5a5-20e3-4b6b-97a5-f134b0b34d50",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "f250a5a5-20e3-4b6b-97a5-f134b0b34d50",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_f250a5a5-20e3-4b6b-97a5-f134b0b34d50\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent f250a5a5-20e3-4b6b-97a5-f134b0b34d50</b></p><a name=\"f250a5a5-20e3-4b6b-97a5-f134b0b34d50\"> </a><a name=\"hcf250a5a5-20e3-4b6b-97a5-f134b0b34d50\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_erheben}\">Erfassung medizinischer Daten</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2026-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_erheben}\">Erfassung medizinischer Daten</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.6}\">MDAT erheben</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "MDAT_erheben",
              "display" : "Erfassung medizinischer Daten"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2026-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "MDAT_erheben",
                  "display" : "Erfassung medizinischer Daten"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.6"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:7159f7db-a76f-41a5-b831-10c972a3a282",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "7159f7db-a76f-41a5-b831-10c972a3a282",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_7159f7db-a76f-41a5-b831-10c972a3a282\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 7159f7db-a76f-41a5-b831-10c972a3a282</b></p><a name=\"7159f7db-a76f-41a5-b831-10c972a3a282\"> </a><a name=\"hc7159f7db-a76f-41a5-b831-10c972a3a282\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_GECCO83_bereitstellen_NUM_CODEX}\">Medizinische Daten des GECCO83 Datensatz für wiss. Nutzung in NUM-CODEX Plattform bereitstellen</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_GECCO83_bereitstellen_NUM_CODEX}\">Medizinische Daten des GECCO83 Datensatz für wiss. Nutzung in NUM-CODEX Plattform bereitstellen</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.33}\">MDAT GECCO83 bereitstellen NUM/CODEX</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "MDAT_GECCO83_bereitstellen_NUM_CODEX",
              "display" : "Medizinische Daten des GECCO83 Datensatz für wiss. Nutzung in NUM-CODEX Plattform bereitstellen"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "MDAT_GECCO83_bereitstellen_NUM_CODEX",
                  "display" : "Medizinische Daten des GECCO83 Datensatz für wiss. Nutzung in NUM-CODEX Plattform bereitstellen"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.33"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:b790946a-8a5c-48ed-926b-02ab9342e0ab",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "b790946a-8a5c-48ed-926b-02ab9342e0ab",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_b790946a-8a5c-48ed-926b-02ab9342e0ab\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent b790946a-8a5c-48ed-926b-02ab9342e0ab</b></p><a name=\"b790946a-8a5c-48ed-926b-02ab9342e0ab\"> </a><a name=\"hcb790946a-8a5c-48ed-926b-02ab9342e0ab\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_GECCO83_bereitstellen_NUM_CODEX_non_EU_DSGVO_NIVEAU}\">Medizinische Daten des GECCO83 Datensatz an Länder ohne EU Datenschutzniveau weitergeben</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_GECCO83_bereitstellen_NUM_CODEX_non_EU_DSGVO_NIVEAU}\">Medizinische Daten des GECCO83 Datensatz an Länder ohne EU Datenschutzniveau weitergeben</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.36}\">MDAT GECCO83 bereitstellen NUM/CODEX ohne EU DSGVO NIVEAU</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "MDAT_GECCO83_bereitstellen_NUM_CODEX_non_EU_DSGVO_NIVEAU",
              "display" : "Medizinische Daten des GECCO83 Datensatz an Länder ohne EU Datenschutzniveau weitergeben"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "MDAT_GECCO83_bereitstellen_NUM_CODEX_non_EU_DSGVO_NIVEAU",
                  "display" : "Medizinische Daten des GECCO83 Datensatz an Länder ohne EU Datenschutzniveau weitergeben"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.36"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:29e8f702-9949-48d0-82b8-64afae92354e",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "29e8f702-9949-48d0-82b8-64afae92354e",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_29e8f702-9949-48d0-82b8-64afae92354e\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 29e8f702-9949-48d0-82b8-64afae92354e</b></p><a name=\"29e8f702-9949-48d0-82b8-64afae92354e\"> </a><a name=\"hc29e8f702-9949-48d0-82b8-64afae92354e\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_GECCO83_speichern_verarbeiten_NUM_CODEX}\">Medizinische Daten des GECCO83 Datensatz in NUM-CODEX Plattform speichern und verarbeiten</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_GECCO83_speichern_verarbeiten_NUM_CODEX}\">Medizinische Daten des GECCO83 Datensatz in NUM-CODEX Plattform speichern und verarbeiten</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.34}\">MDAT GECCO83 speichern verarbeiten NUM/CODEX</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "MDAT_GECCO83_speichern_verarbeiten_NUM_CODEX",
              "display" : "Medizinische Daten des GECCO83 Datensatz in NUM-CODEX Plattform speichern und verarbeiten"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "MDAT_GECCO83_speichern_verarbeiten_NUM_CODEX",
                  "display" : "Medizinische Daten des GECCO83 Datensatz in NUM-CODEX Plattform speichern und verarbeiten"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.34"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:7726b2ea-ea25-4848-a666-2135bf384cff",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "7726b2ea-ea25-4848-a666-2135bf384cff",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_7726b2ea-ea25-4848-a666-2135bf384cff\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 7726b2ea-ea25-4848-a666-2135bf384cff</b></p><a name=\"7726b2ea-ea25-4848-a666-2135bf384cff\"> </a><a name=\"hc7726b2ea-ea25-4848-a666-2135bf384cff\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://mii.de/fhir/CodeSystem/gics/Policy/MII MDAT_GECCO83_wissenschaftlich_nutzen_COVID_19_Forschung_EU_DSGVO_konform}\">Nutzung des Covid-19-Datensatzes auf der im Rahmen des Projekts NUM-CODEX aufgebauten zentralen Datenplattform für die COVID-19-Forschung</span></p><h3>Provisions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Period</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>Opt In</td><td>2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</td><td><span title=\"Codes:{https://mii.de/fhir/CodeSystem/gics/Policy/MII MDAT_GECCO83_wissenschaftlich_nutzen_COVID_19_Forschung_EU_DSGVO_konform}\">Nutzung des Covid-19-Datensatzes auf der im Rahmen des Projekts NUM-CODEX aufgebauten zentralen Datenplattform für die COVID-19-Forschung</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://mii.de/fhir/CodeSystem/gics/Policy/MII",
              "code" : "MDAT_GECCO83_wissenschaftlich_nutzen_COVID_19_Forschung_EU_DSGVO_konform",
              "display" : "Nutzung des Covid-19-Datensatzes auf der im Rahmen des Projekts NUM-CODEX aufgebauten zentralen Datenplattform für die COVID-19-Forschung"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://mii.de/fhir/CodeSystem/gics/Policy/MII",
                  "code" : "MDAT_GECCO83_wissenschaftlich_nutzen_COVID_19_Forschung_EU_DSGVO_konform",
                  "display" : "Nutzung des Covid-19-Datensatzes auf der im Rahmen des Projekts NUM-CODEX aufgebauten zentralen Datenplattform für die COVID-19-Forschung"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:3fc1cb1f-e37c-4c5a-9b46-c6edc1459aa6",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "3fc1cb1f-e37c-4c5a-9b46-c6edc1459aa6",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_3fc1cb1f-e37c-4c5a-9b46-c6edc1459aa6\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 3fc1cb1f-e37c-4c5a-9b46-c6edc1459aa6</b></p><a name=\"3fc1cb1f-e37c-4c5a-9b46-c6edc1459aa6\"> </a><a name=\"hc3fc1cb1f-e37c-4c5a-9b46-c6edc1459aa6\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://mii.de/fhir/CodeSystem/gics/Policy/MII MDAT_GECCO83_wissenschaftlich_nutzen_Pandemie_Forschung_EU_DSGVO_konform}\">Nutzung des Covid-19-Datensatzes auf der im Rahmen des Projekts NUM-CODEX aufgebauten zentralen Datenplattform für die Pandemie-Forschung</span></p><h3>Provisions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Period</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>Opt In</td><td>2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</td><td><span title=\"Codes:{https://mii.de/fhir/CodeSystem/gics/Policy/MII MDAT_GECCO83_wissenschaftlich_nutzen_Pandemie_Forschung_EU_DSGVO_konform}\">Nutzung des Covid-19-Datensatzes auf der im Rahmen des Projekts NUM-CODEX aufgebauten zentralen Datenplattform für die Pandemie-Forschung</span></td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://mii.de/fhir/CodeSystem/gics/Policy/MII",
              "code" : "MDAT_GECCO83_wissenschaftlich_nutzen_Pandemie_Forschung_EU_DSGVO_konform",
              "display" : "Nutzung des Covid-19-Datensatzes auf der im Rahmen des Projekts NUM-CODEX aufgebauten zentralen Datenplattform für die Pandemie-Forschung"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://mii.de/fhir/CodeSystem/gics/Policy/MII",
                  "code" : "MDAT_GECCO83_wissenschaftlich_nutzen_Pandemie_Forschung_EU_DSGVO_konform",
                  "display" : "Nutzung des Covid-19-Datensatzes auf der im Rahmen des Projekts NUM-CODEX aufgebauten zentralen Datenplattform für die Pandemie-Forschung"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:9d317d12-e34f-4b4f-a9c1-693ecf7e1615",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "9d317d12-e34f-4b4f-a9c1-693ecf7e1615",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_9d317d12-e34f-4b4f-a9c1-693ecf7e1615\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 9d317d12-e34f-4b4f-a9c1-693ecf7e1615</b></p><a name=\"9d317d12-e34f-4b4f-a9c1-693ecf7e1615\"> </a><a name=\"hc9d317d12-e34f-4b4f-a9c1-693ecf7e1615\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_speichern_verarbeiten}\">Speicherung_Verarbeitung von medizinischen Daten innerhalb der verantwortlichen Stelle (MDAT)</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_speichern_verarbeiten}\">Speicherung_Verarbeitung von medizinischen Daten innerhalb der verantwortlichen Stelle (MDAT)</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.7}\">MDAT speichern, verarbeiten</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "MDAT_speichern_verarbeiten",
              "display" : "Speicherung_Verarbeitung von medizinischen Daten innerhalb der verantwortlichen Stelle (MDAT)"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "MDAT_speichern_verarbeiten",
                  "display" : "Speicherung_Verarbeitung von medizinischen Daten innerhalb der verantwortlichen Stelle (MDAT)"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.7"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:8fead334-f5a9-4025-b604-5e38f9ad44c3",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "8fead334-f5a9-4025-b604-5e38f9ad44c3",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_8fead334-f5a9-4025-b604-5e38f9ad44c3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent 8fead334-f5a9-4025-b604-5e38f9ad44c3</b></p><a name=\"8fead334-f5a9-4025-b604-5e38f9ad44c3\"> </a><a name=\"hc8fead334-f5a9-4025-b604-5e38f9ad44c3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU}\">Bereitstellung medizinischer Daten (MDAT) für wissenschaftliche Nutzung </span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU}\">Bereitstellung medizinischer Daten (MDAT) für wissenschaftliche Nutzung </span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.8}\">MDAT wissenschaftlich nutzen EU DSGVO NIVEAU</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "MDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU",
              "display" : "Bereitstellung medizinischer Daten (MDAT) für wissenschaftliche Nutzung "
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "MDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU",
                  "display" : "Bereitstellung medizinischer Daten (MDAT) für wissenschaftliche Nutzung "
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.8"
                }
              ]
            }
          ]
        }
      }
    },
    {
      "fullUrl" : "urn:uuid:a778fd9a-e68a-4b98-ab9d-2d788db705d5",
      "resource" : {
        "resourceType" : "Consent",
        "id" : "a778fd9a-e68a-4b98-ab9d-2d788db705d5",
        "meta" : {
          "lastUpdated" : "2021-06-03T09:47:47.361+02:00",
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent",
            "http://fhir.de/ConsentManagement/StructureDefinition/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_a778fd9a-e68a-4b98-ab9d-2d788db705d5\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent a778fd9a-e68a-4b98-ab9d-2d788db705d5</b></p><a name=\"a778fd9a-e68a-4b98-ab9d-2d788db705d5\"> </a><a name=\"hca778fd9a-e68a-4b98-ab9d-2d788db705d5\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\">Last updated: 2021-06-03 09:47:47+0200</p><p style=\"margin-bottom: 0px\">Profiles: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a>, <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.de/ConsentManagement/StructureDefinition/Consent\">Consent Management: Consent</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 57016-8}\">Privacy policy acknowledgment Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType policy}\">Policy</span></p><p><b>patient</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/Patient/34d195ef-179f-48dd-b830-d52ea9347157\">Pseudonym dic_GCC83</a></p><p><b>dateTime</b>: 2021-06-03 00:00:00+0200</p><p><b>source</b>: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.2&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56\">QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56</a></p><p><b>policyRule</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_zusammenfuehren_Dritte}\">Zusammenführung medizinischer Daten (MDAT) mit Dritten Forschungspartnern</span></p><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2021-06-03 09:47:47+0200 --&gt; 2051-06-03 09:47:47+0200</p><p><b>code</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy MDAT_zusammenfuehren_Dritte}\">Zusammenführung medizinischer Daten (MDAT) mit Dritten Forschungspartnern</span>, <span title=\"Codes:{urn:oid:2.16.840.1.113883.3.1937.777.24.5.3 2.16.840.1.113883.3.1937.777.24.5.3.9}\">MDAT zusammenfuehren Dritte</span></p></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "57016-8"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "policy"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/34d195ef-179f-48dd-b830-d52ea9347157",
          "display" : "Pseudonym dic_GCC83"
        },
        "dateTime" : "2021-06-03T00:00:00+02:00",
        "sourceReference" : {
          "reference" : "QuestionnaireResponse/5cfc1218-618f-4408-9e3d-a1af7a25aa56"
        },
        "policyRule" : {
          "coding" : [
            {
              "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
              "code" : "MDAT_zusammenfuehren_Dritte",
              "display" : "Zusammenführung medizinischer Daten (MDAT) mit Dritten Forschungspartnern"
            }
          ]
        },
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2021-06-03T09:47:47+02:00",
            "end" : "2051-06-03T09:47:47+02:00"
          },
          "code" : [
            {
              "coding" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                  "code" : "MDAT_zusammenfuehren_Dritte",
                  "display" : "Zusammenführung medizinischer Daten (MDAT) mit Dritten Forschungspartnern"
                }
              ]
            },
            {
              "coding" : [
                {
                  "system" : "urn:oid:2.16.840.1.113883.3.1937.777.24.5.3",
                  "code" : "2.16.840.1.113883.3.1937.777.24.5.3.9"
                }
              ]
            }
          ]
        }
      }
    }
  ]
}

```
