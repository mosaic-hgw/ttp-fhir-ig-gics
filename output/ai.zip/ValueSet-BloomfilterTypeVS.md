# BloomfilterType - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BloomfilterTypeVS",
  "url" : "https://ths-greifswald.de/fhir/ValueSet/epix/BloomfilterType",
  "version" : "2025.2.0",
  "name" : "BloomfilterType",
  "status" : "draft",
  "experimental" : false,
  "date" : "2025-06-12",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [
    {
      "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.ths-greifswald.de/"
        }
      ]
    }
  ],
  "copyright" : "Copyright 2020-2025 Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "compose" : {
    "include" : [
      {
        "system" : "https://ths-greifswald.de/fhir/CodeSystem/epix/BloomfilterType"
      }
    ]
  }
}

```
