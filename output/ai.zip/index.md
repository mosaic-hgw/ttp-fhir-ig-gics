# Implementation Guide gICS - v2025.2.0

