# example-BatchResponse-provideCD - v2025.1.0



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "example-BatchResponse-provideCD",
  "type" : "batch-response",
  "entry" : [
    {
      "resource" : {
        "resourceType" : "Patient",
        "id" : "example-provideCD-patient1",
        "meta" : {
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/fttp/PatientPseudonymized"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_example-provideCD-patient1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient example-provideCD-patient1</b></p><a name=\"example-provideCD-patient1\"> </a><a name=\"hcexample-provideCD-patient1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-PatientPseudonymized.html\">Patient pseudonymisiert</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anonymous Patient (no stated gender), DoB Unknown ( http://my-hospital.de/sid/psn#dic1_PSN1)</p><hr/></div>"
        },
        "identifier" : [
          {
            "system" : "http://my-hospital.de/sid/psn",
            "value" : "dic1_PSN1"
          }
        ]
      },
      "response" : {
        "status" : "201",
        "location" : "https://fhir-server.my-hospital.de/fhir/Patient/example-provideCD-patient1",
        "etag" : "W/\"1\"",
        "lastModified" : "2025-06-30T12:34:56Z"
      }
    },
    {
      "resource" : {
        "resourceType" : "Patient",
        "id" : "example-provideCD-patient2",
        "meta" : {
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/fttp/PatientPseudonymized"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_example-provideCD-patient2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient example-provideCD-patient2</b></p><a name=\"example-provideCD-patient2\"> </a><a name=\"hcexample-provideCD-patient2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-PatientPseudonymized.html\">Patient pseudonymisiert</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anonymous Patient (no stated gender), DoB Unknown ( http://my-hospital.de/sid/psn#dic2_PSN2)</p><hr/></div>"
        },
        "identifier" : [
          {
            "system" : "http://my-hospital.de/sid/psn",
            "value" : "dic2_PSN2"
          }
        ]
      },
      "response" : {
        "status" : "201",
        "location" : "https://fhir-server.my-hospital.de/fhir/Patient/example-provideCD-patient2",
        "etag" : "W/\"1\"",
        "lastModified" : "2025-06-30T12:34:56Z"
      }
    },
    {
      "resource" : {
        "resourceType" : "Patient",
        "id" : "example-provideCD-patient3",
        "meta" : {
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/fttp/PatientPseudonymized"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Patient_example-provideCD-patient3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Patient example-provideCD-patient3</b></p><a name=\"example-provideCD-patient3\"> </a><a name=\"hcexample-provideCD-patient3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-PatientPseudonymized.html\">Patient pseudonymisiert</a></p></div><p style=\"border: 1px #661aff solid; background-color: #e6e6ff; padding: 10px;\">Anonymous Patient (no stated gender), DoB Unknown ( http://my-hospital.de/sid/psn#dic3_PSN3)</p><hr/></div>"
        },
        "identifier" : [
          {
            "system" : "http://my-hospital.de/sid/psn",
            "value" : "dic3_PSN3"
          }
        ]
      },
      "response" : {
        "status" : "201",
        "location" : "https://fhir-server.my-hospital.de/fhir/Patient/example-provideCD-patient3",
        "etag" : "W/\"1\"",
        "lastModified" : "2025-06-30T12:34:56Z"
      }
    },
    {
      "resource" : {
        "resourceType" : "Consent",
        "id" : "example-provideCD-consent1",
        "meta" : {
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_example-provideCD-consent1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent example-provideCD-consent1</b></p><a name=\"example-provideCD-consent1\"> </a><a name=\"hcexample-provideCD-consent1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>domain: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.0&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/ResearchStudy/REGISTERA\">ResearchStudy/REGISTERA</a></li><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 59284-0}\">Consent Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType document}\">Dokument</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/TemplateType CONSENT-OPT-IN}\">Einwilligung (Opt-in)</span></p><p><b>patient</b>: <a href=\"Bundle-example-Batch-provideCD.html#Patient_example-provideCD-patient1\">Anonymous Patient (no stated gender), DoB Unknown ( http://my-hospital.de/sid/psn#dic1_PSN1)</a></p><p><b>dateTime</b>: 2025-06-26 13:14:15+0200</p><p><b>organization</b>: Testorganisation</p><h3>Policies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Uri</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.0&amp;canonical=urn:uuid:b0b83c00-e230-4c52-8d3a-cbb882e0a72f\">urn:uuid:b0b83c00-e230-4c52-8d3a-cbb882e0a72f</a></td></tr></table><blockquote><p><b>provision</b></p><p><b>type</b>: Opt Out</p><p><b>period</b>: 2021-10-29 11:00:08+0200 --&gt; 2021-11-30 00:00:00+0100</p><h3>Provisions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Period</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>Opt In</td><td>2021-10-29 11:00:08+0200 --&gt; 2021-11-30 00:00:00+0100</td><td><span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_bereitstellen_EU_DSGVO_NIVEAU}\">Herausgabe identifizierender Daten (IDAT) an verantwortliche Stelle zur weiteren Verarbeitung</span></td></tr><tr><td style=\"display: none\">*</td><td>Opt In</td><td>2021-10-29 11:00:08+0200 --&gt; 2021-11-30 00:00:00+0100</td><td><span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_erheben}\">Erfassung neuer identifizierender Daten (IDAT)</span></td></tr><tr><td style=\"display: none\">*</td><td>Opt In</td><td>2021-10-29 11:00:08+0200 --&gt; 2021-11-30 00:00:00+0100</td><td><span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_speichern_verarbeiten}\">Speicherung und Verarbeitung identifizierender Daten (IDAT) in der verantwortlichen Stelle</span></td></tr><tr><td style=\"display: none\">*</td><td>Opt In</td><td>2021-10-29 11:00:08+0200 --&gt; 2021-11-30 00:00:00+0100</td><td><span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/Policy IDAT_zusammenfuehren_Dritte}\">Zusammenführung identifizierender Daten (IDAT) mit Dritten Forschungspartnern</span></td></tr></table></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "domain",
                "valueReference" : {
                  "reference" : "ResearchStudy/REGISTERA"
                }
              },
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "59284-0"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "document"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/TemplateType",
                "code" : "CONSENT-OPT-IN"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/example-provideCD-patient1"
        },
        "dateTime" : "2025-06-26T13:14:15+02:00",
        "organization" : [
          {
            "display" : "Testorganisation"
          }
        ],
        "policy" : [
          {
            "uri" : "urn:uuid:b0b83c00-e230-4c52-8d3a-cbb882e0a72f"
          }
        ],
        "provision" : {
          "type" : "deny",
          "period" : {
            "start" : "2021-10-29T11:00:08+02:00",
            "end" : "2021-11-30T00:00:00+01:00"
          },
          "provision" : [
            {
              "type" : "permit",
              "period" : {
                "start" : "2021-10-29T11:00:08+02:00",
                "end" : "2021-11-30T00:00:00+01:00"
              },
              "code" : [
                {
                  "coding" : [
                    {
                      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                      "code" : "IDAT_bereitstellen_EU_DSGVO_NIVEAU",
                      "display" : "Herausgabe identifizierender Daten (IDAT) an verantwortliche Stelle zur weiteren Verarbeitung"
                    }
                  ]
                }
              ]
            },
            {
              "type" : "permit",
              "period" : {
                "start" : "2021-10-29T11:00:08+02:00",
                "end" : "2021-11-30T00:00:00+01:00"
              },
              "code" : [
                {
                  "coding" : [
                    {
                      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                      "code" : "IDAT_erheben",
                      "display" : "Erfassung neuer identifizierender Daten (IDAT)"
                    }
                  ]
                }
              ]
            },
            {
              "type" : "permit",
              "period" : {
                "start" : "2021-10-29T11:00:08+02:00",
                "end" : "2021-11-30T00:00:00+01:00"
              },
              "code" : [
                {
                  "coding" : [
                    {
                      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                      "code" : "IDAT_speichern_verarbeiten",
                      "display" : "Speicherung und Verarbeitung identifizierender Daten (IDAT) in der verantwortlichen Stelle"
                    }
                  ]
                }
              ]
            },
            {
              "type" : "permit",
              "period" : {
                "start" : "2021-10-29T11:00:08+02:00",
                "end" : "2021-11-30T00:00:00+01:00"
              },
              "code" : [
                {
                  "coding" : [
                    {
                      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
                      "code" : "IDAT_zusammenfuehren_Dritte",
                      "display" : "Zusammenführung identifizierender Daten (IDAT) mit Dritten Forschungspartnern"
                    }
                  ]
                }
              ]
            }
          ]
        }
      },
      "response" : {
        "status" : "201",
        "location" : "https://fhir-server.my-hospital.de/fhir/Consent/example-provideCD-consent1",
        "etag" : "W/\"1\"",
        "lastModified" : "2025-06-30T12:34:56Z"
      }
    },
    {
      "resource" : {
        "resourceType" : "Consent",
        "id" : "example-provideCD-consent2",
        "meta" : {
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_example-provideCD-consent2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent example-provideCD-consent2</b></p><a name=\"example-provideCD-consent2\"> </a><a name=\"hcexample-provideCD-consent2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>domain: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.0&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/ResearchStudy/REGISTERA\">ResearchStudy/REGISTERA</a></li><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope research}\">Research</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 59284-0}\">Consent Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType document}\">Dokument</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/TemplateType WITHDRAWAL}\">Widerrufsvorlage</span></p><p><b>patient</b>: <a href=\"Bundle-example-Batch-provideCD.html#Patient_example-provideCD-patient2\">Anonymous Patient (no stated gender), DoB Unknown ( http://my-hospital.de/sid/psn#dic2_PSN2)</a></p><p><b>dateTime</b>: 2025-06-26 13:14:15+0200</p><p><b>organization</b>: Testorganisation</p><h3>Policies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Uri</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.0&amp;canonical=urn:uuid:b0b83c00-e230-4c52-8d3a-cbb882e0a72f\">urn:uuid:b0b83c00-e230-4c52-8d3a-cbb882e0a72f</a></td></tr></table><h3>Provisions</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Period</b></td></tr><tr><td style=\"display: none\">*</td><td>Opt Out</td><td>2021-11-01 13:00:08+0200 --&gt; 2021-11-30 00:00:00+0100</td></tr></table></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "domain",
                "valueReference" : {
                  "reference" : "ResearchStudy/REGISTERA"
                }
              },
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "research"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "59284-0"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "document"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/TemplateType",
                "code" : "WITHDRAWAL"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/example-provideCD-patient2"
        },
        "dateTime" : "2025-06-26T13:14:15+02:00",
        "organization" : [
          {
            "display" : "Testorganisation"
          }
        ],
        "policy" : [
          {
            "uri" : "urn:uuid:b0b83c00-e230-4c52-8d3a-cbb882e0a72f"
          }
        ],
        "provision" : {
          "type" : "deny",
          "period" : {
            "start" : "2021-11-01T13:00:08+02:00",
            "end" : "2021-11-30T00:00:00+01:00"
          }
        }
      },
      "response" : {
        "status" : "201",
        "location" : "https://fhir-server.my-hospital.de/fhir/Consent/example-provideCD-consent2",
        "etag" : "W/\"1\"",
        "lastModified" : "2025-06-30T12:34:56Z"
      }
    },
    {
      "resource" : {
        "resourceType" : "Consent",
        "id" : "example-provideCD-consent3",
        "meta" : {
          "profile" : [
            "https://ths-greifswald.de/fhir/StructureDefinition/gics/Consent"
          ]
        },
        "text" : {
          "status" : "extensions",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Consent_example-provideCD-consent3\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Consent example-provideCD-consent3</b></p><a name=\"example-provideCD-consent3\"> </a><a name=\"hcexample-provideCD-consent3\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-Consent.html\">Einwilligungsinformationen</a></p></div><blockquote><p><b>Consent Management Domain Reference</b></p><ul><li>domain: <a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.0&amp;canonical=http://fhir.org/packages/de.einwilligungsmanagement/ResearchStudy/EPA\">ResearchStudy/EPA</a></li><li>status: <a href=\"http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-active\">PublicationStatus active</a>: Active</li></ul></blockquote><p><b>status</b>: Active</p><p><b>scope</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/consentscope treatment}\">Treatment</span></p><p><b>category</b>: <span title=\"Codes:{http://loinc.org 59284-0}\">Consent Document</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/ResultType document}\">Dokument</span>, <span title=\"Codes:{http://fhir.de/ConsentManagement/CodeSystem/TemplateType CONSENT-OPT-OUT}\">Einwilligung (Opt-out)</span></p><p><b>patient</b>: <a href=\"Bundle-example-Batch-provideCD.html#Patient_example-provideCD-patient3\">Anonymous Patient (no stated gender), DoB Unknown ( http://my-hospital.de/sid/psn#dic3_PSN3)</a></p><p><b>dateTime</b>: 2025-06-26 13:14:15+0200</p><p><b>organization</b>: EPA</p><h3>Policies</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Uri</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://simplifier.net/resolve?scope=de.einwilligungsmanagement@2.0.0&amp;canonical=https://www.gesetze-im-internet.de/sgb_5/__342.html\">https://www.gesetze-im-internet.de/sgb_5/__342.html</a></td></tr></table><blockquote><p><b>provision</b></p><p><b>type</b>: Opt In</p><p><b>period</b>: 2025-03-04 15:16:17+0200 --&gt; (ongoing)</p><blockquote><p><b>provision</b></p><h3>Actors</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Role</b></td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyActor TTP}\">TTP</span></td><td>TTP Greifswald</td></tr></table><p><b>action</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyAction collect}\">collect</span></p><p><b>class</b>: <a href=\"CodeSystem-ConsentPolicyClassCS.html#ConsentPolicyClassCS-PII\">ConsentPolicyClass PII</a>: PII</p></blockquote><blockquote><p><b>provision</b></p><h3>Actors</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Role</b></td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyActor DIC}\">DIC</span></td><td>Datenintegrationszentrum Greifswald</td></tr></table><p><b>action</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyAction collect}\">collect</span></p><p><b>class</b>: <a href=\"CodeSystem-ConsentPolicyClassCS.html#ConsentPolicyClassCS-MDAT\">ConsentPolicyClass MDAT</a>: MDAT</p></blockquote><blockquote><p><b>provision</b></p><h3>Actors</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Role</b></td><td><b>Reference</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyActor DTU}\">DTU</span></td><td>Transferstelle der Universitätsmedizin Greifswald</td></tr></table><p><b>action</b>: <span title=\"Codes:{https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyAction provide}\">provide</span></p><p><b>purpose</b>: <a href=\"CodeSystem-ConsentPolicyPurposeCS.html#ConsentPolicyPurposeCS-EU_GDPR_LEVEL\">ConsentPolicyPurpose EU_GDPR_LEVEL</a>: EU_GDPR_LEVEL, <a href=\"CodeSystem-ConsentPolicyPurposeCS.html#ConsentPolicyPurposeCS-timely_unrestricted\">ConsentPolicyPurpose timely_unrestricted</a>: timely_unrestricted </p><p><b>class</b>: <a href=\"CodeSystem-ConsentPolicyClassCS.html#ConsentPolicyClassCS-MDAT\">ConsentPolicyClass MDAT</a>: MDAT</p></blockquote></blockquote></div>"
        },
        "extension" : [
          {
            "extension" : [
              {
                "url" : "domain",
                "valueReference" : {
                  "reference" : "ResearchStudy/EPA"
                }
              },
              {
                "url" : "status",
                "valueCoding" : {
                  "system" : "http://hl7.org/fhir/publication-status",
                  "code" : "active"
                }
              }
            ],
            "url" : "http://fhir.de/ConsentManagement/StructureDefinition/DomainReference"
          }
        ],
        "status" : "active",
        "scope" : {
          "coding" : [
            {
              "system" : "http://terminology.hl7.org/CodeSystem/consentscope",
              "code" : "treatment"
            }
          ]
        },
        "category" : [
          {
            "coding" : [
              {
                "system" : "http://loinc.org",
                "code" : "59284-0"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/ResultType",
                "code" : "document"
              }
            ]
          },
          {
            "coding" : [
              {
                "system" : "http://fhir.de/ConsentManagement/CodeSystem/TemplateType",
                "code" : "CONSENT-OPT-OUT"
              }
            ]
          }
        ],
        "patient" : {
          "reference" : "Patient/example-provideCD-patient3"
        },
        "dateTime" : "2025-06-26T13:14:15+02:00",
        "organization" : [
          {
            "display" : "EPA"
          }
        ],
        "policy" : [
          {
            "uri" : "https://www.gesetze-im-internet.de/sgb_5/__342.html"
          }
        ],
        "provision" : {
          "type" : "permit",
          "period" : {
            "start" : "2025-03-04T15:16:17+02:00"
          },
          "provision" : [
            {
              "actor" : [
                {
                  "role" : {
                    "coding" : [
                      {
                        "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyActor",
                        "code" : "TTP"
                      }
                    ]
                  },
                  "reference" : {
                    "display" : "TTP Greifswald"
                  }
                }
              ],
              "action" : [
                {
                  "coding" : [
                    {
                      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyAction",
                      "code" : "collect"
                    }
                  ]
                }
              ],
              "class" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyClass",
                  "code" : "PII"
                }
              ]
            },
            {
              "actor" : [
                {
                  "role" : {
                    "coding" : [
                      {
                        "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyActor",
                        "code" : "DIC"
                      }
                    ]
                  },
                  "reference" : {
                    "display" : "Datenintegrationszentrum Greifswald"
                  }
                }
              ],
              "action" : [
                {
                  "coding" : [
                    {
                      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyAction",
                      "code" : "collect"
                    }
                  ]
                }
              ],
              "class" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyClass",
                  "code" : "MDAT"
                }
              ]
            },
            {
              "actor" : [
                {
                  "role" : {
                    "coding" : [
                      {
                        "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyActor",
                        "code" : "DTU"
                      }
                    ]
                  },
                  "reference" : {
                    "display" : "Transferstelle der Universitätsmedizin Greifswald"
                  }
                }
              ],
              "action" : [
                {
                  "coding" : [
                    {
                      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyAction",
                      "code" : "provide"
                    }
                  ]
                }
              ],
              "purpose" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyPurpose",
                  "code" : "EU_GDPR_LEVEL"
                },
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyPurpose",
                  "code" : "timely_unrestricted"
                }
              ],
              "class" : [
                {
                  "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentPolicyClass",
                  "code" : "MDAT"
                }
              ]
            }
          ]
        }
      },
      "response" : {
        "status" : "201",
        "location" : "https://fhir-server.my-hospital.de/fhir/Consent/example-provideCD-consent3",
        "etag" : "W/\"1\"",
        "lastModified" : "2025-06-30T12:34:56Z"
      }
    }
  ]
}

```
