# Policy - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "PolicyCS",
  "url" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
  "version" : "2025.2.0",
  "name" : "Policy",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-06-12",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [{
    "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ths-greifswald.de/"
    }]
  }],
  "description" : "Policies used in consent management",
  "copyright" : "Copyright 2020-2025 Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 75,
  "concept" : [{
    "code" : "IDAT_erheben",
    "display" : "Erfassung neuer identifizierender Daten (IDAT)"
  },
  {
    "code" : "IDAT_erheben_Institutionen",
    "display" : "Erfassung identifizierender Daten durch Anfrage bei Melderegister oder Krankenversicherung"
  },
  {
    "code" : "IDAT_speichern_verarbeiten",
    "display" : "Speicherung und Verarbeitung identifizierender Daten (IDAT) in der verantwortlichen Stelle"
  },
  {
    "code" : "IDAT_bereitstellen_Arzt",
    "display" : "Weitergabe von identifizierenden Daten an beliebigen Arzt (inkl. Hausarzt)"
  },
  {
    "code" : "IDAT_bereitstellen_Hausarzt",
    "display" : "Weitergabe von identifizierenden Daten an Hausarzt"
  },
  {
    "code" : "IDAT_bereitstellen_Institutionen",
    "display" : "Weitergabe von identifizierenden Daten an Melderegeister oder Krankenversicherung zum Zweck der Datenergänzung"
  },
  {
    "code" : "IDAT_bereitstellen_Institutionen_Tod",
    "display" : "Weitergabe von identifizierenden Daten an Melderegeister oder Krankenversicherung zum Zweck der Datenergänzung im Falle des Todes"
  },
  {
    "code" : "IDAT_bereitstellen_EU_DSGVO_NIVEAU",
    "display" : "Herausgabe identifizierender Daten (IDAT) an verantwortliche Stelle zur weiteren Verarbeitung"
  },
  {
    "code" : "IDAT_Einsicht_Monitoring",
    "display" : "Einsicht in identifizierende Daten im Rahmen des Monitoring"
  },
  {
    "code" : "IDAT_zusammenfuehren_Dritte",
    "display" : "Zusammenführung identifizierender Daten (IDAT) mit Dritten Forschungspartnern"
  },
  {
    "code" : "MDAT_erheben",
    "display" : "Erfassung medizinischer Daten"
  },
  {
    "code" : "MDAT_erheben_Arzt",
    "display" : "Erfassung medizinischer Daten durch Anfrage bei externem Arzt (inkl. Hausarzt)"
  },
  {
    "code" : "MDAT_erheben_Hausarzt",
    "display" : "Erfassung medizinischer Daten durch Anfrage beim Hausarzt"
  },
  {
    "code" : "MDAT_erheben_Institutionen",
    "display" : "Erfassung medizinischer Daten durch Anfrage bei Institutionen, wie z.B. Gesundheitsamt, Kassenärztliche Vereinigung, Melderegister oder Krankenversicherung"
  },
  {
    "code" : "MDAT_erheben_Krankenunterlagen",
    "display" : "Erfassung medizinischer Daten durch Übertrag aus Krankenunterlagen"
  },
  {
    "code" : "MDAT_erheben_Tod",
    "display" : "Erfassung von medizinischen Daten zum Zwecke der Datenergänzung im Falle des Todes"
  },
  {
    "code" : "MDAT_speichern_verarbeiten",
    "display" : "Speicherung_Verarbeitung von medizinischen Daten innerhalb der verantwortlichen Stelle (MDAT)"
  },
  {
    "code" : "MDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU",
    "display" : "Bereitstellung medizinischer Daten (MDAT) für wissenschaftliche Nutzung"
  },
  {
    "code" : "MDAT_bereitstellen_studienintern",
    "display" : "Weitergabe von medizinischen Daten innerhalb der Studie zu Auswertungszwecken"
  },
  {
    "code" : "MDAT_bereitstellen_intern",
    "display" : "Weitergabe von medizinischen Daten innerhalb des Projektes (bspw. DZHK) zu Auswertungszwecken"
  },
  {
    "code" : "MDAT_bereitstellen_EU_DSGVO_NIVEAU",
    "display" : "Weitergabe von medizinischen Daten an externe Wissenschaftler in DSGVO konformen Ländern"
  },
  {
    "code" : "MDAT_bereitstellen_non_EU_DSGVO_NIVEAU",
    "display" : "Weitergabe von medizinischen Daten an externe Wissenschaftler in nicht DSGVO konformen Ländern"
  },
  {
    "code" : "MDAT_bereitstellen_pharma",
    "display" : "Weitergabe von medizinischen Daten an eine am Sponsoring beteiligte Pharmafirma"
  },
  {
    "code" : "MDAT_bereitstellen_CRO",
    "display" : "Weitergabe von medizinischen Daten an eine Clinical Research Organisation"
  },
  {
    "code" : "MDAT_zusammenfuehren_Dritte",
    "display" : "Zusammenführung medizinischer Daten (MDAT) mit Dritten Forschungspartnern"
  },
  {
    "code" : "MDAT_Einsicht_Monitoring",
    "display" : "Einsicht in medizinische Daten im Rahmen des Monitoring"
  },
  {
    "code" : "MDAT_GECCO83_bereitstellen_NUM_CODEX",
    "display" : "Medizinische Daten des GECCO83 Datensatz für wiss. Nutzung in NUM-CODEX Plattform bereitstellen"
  },
  {
    "code" : "MDAT_GECCO83_speichern_verarbeiten_NUM_CODEX",
    "display" : "Medizinische Daten des GECCO83 Datensatz in NUM-CODEX Plattform speichern und verarbeiten"
  },
  {
    "code" : "MDAT_GECCO83_bereitstellen_NUM_CODEX_non_EU_DSGVO_NIVEAU",
    "display" : "Medizinische Daten des GECCO83 Datensatz an Länder ohne EU Datenschutzniveau weitergeben"
  },
  {
    "code" : "IMGDAT_erheben",
    "display" : "Erfassung von Bildern und Bilddaten"
  },
  {
    "code" : "IMGDAT_speichern_verarbeiten",
    "display" : "Langfristiges Speichern und Verarbeiten von Bildern und Bilddaten"
  },
  {
    "code" : "IMGDAT_bereitstellen_studienintern",
    "display" : "Weitergabe von Bildern und Bilddaten innerhalb der Studie zu Auswertungszwecken"
  },
  {
    "code" : "IMGDAT_bereitstellen_intern",
    "display" : "Weitergabe von Bildern und Bilddaten innerhalb des Projektes (bspw. DZHK) zu Auswertungszwecken"
  },
  {
    "code" : "IMGDAT_bereitstellen_EU_DSGVO_NIVEAU",
    "display" : "Weitergabe von Bildern und Bilddaten an externe Wissenschaftler in DSGVO konformen Ländern"
  },
  {
    "code" : "IMGDAT_bereitstellen_non_EU_DSGVO_NIVEAU",
    "display" : "Weitergabe von Bildern und Bilddaten an externe Wissenschaftler in nicht DSGVO konformen Ländern"
  },
  {
    "code" : "IMGDAT_Einsicht_Monitoring",
    "display" : "Einsicht in Bilder und Bilddaten im Rahmen des Monitoring"
  },
  {
    "code" : "BIOMAT_erheben",
    "display" : "Gewinnung und/oder Entnahme von Biomaterialien und medizinischen Proben"
  },
  {
    "code" : "BIOMAT_erheben_studienintern",
    "display" : "Gewinnung von dem Studienbiomaterial zugeordneten medizinischen Proben ohne Veränderung"
  },
  {
    "code" : "BIOMAT_lagern_verarbeiten_studienintern",
    "display" : "Langfristiges Ablegen von dem Studienbiomaterial zugeordneten medizinischen Proben"
  },
  {
    "code" : "BIOMAT_lagern_verarbeiten",
    "display" : "Lagerung und Verarbeitung von Biomaterialien innerhalb der verantwortlichen Stelle (BIOMAT)"
  },
  {
    "code" : "BIOMAT_bereitstellen_studienintern",
    "display" : "Weitergabe von medizinischen Proben innerhalb der Studie zu Auswertungszwecken"
  },
  {
    "code" : "BIOMAT_bereitstellen_intern",
    "display" : "Weitergabe von medizinischen Proben innerhalb des Projektes (bspw. DZHK) zu Auswertungszwecken"
  },
  {
    "code" : "BIOMAT_bereitstellen_EU_DSGVO_NIVEAU",
    "display" : "Weitergabe von medizinischen Proben an externe Wissenschaftler in DSGVO konformen Ländern"
  },
  {
    "code" : "BIOMAT_bereitstellen_non_EU_DSGVO_NIVEAU",
    "display" : "Weitergabe von medizinischen Proben an externe Wissenschaftler in nicht DSGVO konformen Ländern"
  },
  {
    "code" : "BIOMAT_Eigentum_uebertragen",
    "display" : "Eigentumsübertragung der BIOMAT an den Träger der Biobank"
  },
  {
    "code" : "BIOMAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU",
    "display" : "Bereitstellung Biomaterialien (BIOMAT) für wissenschaftliche Nutzung und Analysen"
  },
  {
    "code" : "BIOMAT_Analysedaten_zusammenfuehren_Dritte",
    "display" : "Zusammenführen von auf Biomaterialien (BIOMAT) basierenden Analysedaten mit Analysedaten Dritter"
  },
  {
    "code" : "BIOMAT_Zusatzmengen_entnehmen",
    "display" : "Entnahme zusätzlicher Mengen von Biomaterialien (BIOMAT)"
  },
  {
    "code" : "BIOMAT_Einsicht_Monitoring",
    "display" : "Einsicht in medizinische Proben im Rahmen des Monitoring"
  },
  {
    "code" : "BIOMAT_Genanalyse",
    "display" : "Gewinnung von genetischen Daten aus Biomaterialien"
  },
  {
    "code" : "KDAT_retro_uebertragen",
    "display" : "Krankenkassendaten (KDAT) für retrospektiv übertragen"
  },
  {
    "code" : "KDAT_retro_speichern_verarbeiten",
    "display" : "Krankenkassendaten (KDAT) retrospektiv speichern_verarbeiten in der verantwortlichen Stelle"
  },
  {
    "code" : "KDAT_retro_wissenschaftlich_nutzen",
    "display" : "Krankenkassendaten (KDAT) retrospektiv wissenschaftlich nutzen"
  },
  {
    "code" : "KDAT_pro_uebertragen",
    "display" : "Krankenkassendaten (KDAT) prospektiv übertragen"
  },
  {
    "code" : "KDAT_pro_speichern_verarbeiten",
    "display" : "Krankenkassendaten (KDAT) prospektiv speichern verarbeiten in der verantwortlichen Stelle"
  },
  {
    "code" : "KDAT_pro_wissenschaftlich_nutzen",
    "display" : "Krankenkassendaten (KDAT) prospektiv wissenschaftlich nutzen"
  },
  {
    "code" : "Rekontaktierung_Abfrage_Gesundheitszustand",
    "display" : "Rekontaktierung des Teilnehmers zur Abfrage des Gesundheitszustandes"
  },
  {
    "code" : "Rekontaktierung_Verknuepfung_Datenbanken",
    "display" : "Rekontaktierung zur Verknüpfung von PatDat mit Info anderer Dbs"
  },
  {
    "code" : "Rekontaktierung_weitere_Studien",
    "display" : "Rekontaktierung bezüglich Information zu neuen Forschungsvorhaben oder Studien"
  },
  {
    "code" : "Rekontaktierung_Zufallsbefund",
    "display" : "Rekontaktierung des Teilnehmers zur Mitteilung von Zufallsbefunden"
  },
  {
    "code" : "Rekontaktierung_weitere_Erhebung",
    "display" : "Rekontaktierung bezüglich Erhebung zusätzlicher Daten"
  },
  {
    "code" : "Information_Hausarzt_Studienteilnahme",
    "display" : "Information des Hausarztes über die Teilnahme des Patienten an der Studie"
  },
  {
    "code" : "Information_Arzt_Studienteilnahme",
    "display" : "Information eines Facharztes des Patienten über die Teilnahme des Patienten an der Studie"
  },
  {
    "code" : "MDAT_retro_speichern_verarbeiten",
    "display" : "Speicherung und retrospektive Verarbeitung von medizinischen Daten innerhalb der verantwortlichen Stelle (MDAT)"
  },
  {
    "code" : "MDAT_retro_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU",
    "display" : "Retrospektive Bereitstellung medizinischer Daten (MDAT) für wissenschaftliche Nutzung"
  },
  {
    "code" : "MDAT_retro_zusammenfuehren_Dritte",
    "display" : "Retrospektive Zusammenführung medizinischer Daten (MDAT) mit Dritten Forschungspartnern"
  },
  {
    "code" : "MDAT_wissenschaftlich_nutzen_non_EU_DSGVO_NIVEAU",
    "display" : "Bereitstellung medizinische Daten (MDAT)  für wissenschaftliche Nutzung  und Analysen für Länder ohne EU DSGVO Niveau"
  },
  {
    "code" : "BIOMAT_retro_lagern_verarbeiten",
    "display" : "Retrospektive Lagerung und Verarbeitung von Biomaterialien innerhalb der verantwortlichen Stelle (BIOMAT) "
  },
  {
    "code" : "BIOMAT_retro_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU",
    "display" : "Retrospektive Bereitstellung Biomaterialien (BIOMAT) für wissenschaftliche Nutzung und Analysen"
  },
  {
    "code" : "SDAT_erheben_KV",
    "display" : "Erfassung Sozialversicherungsdaten von Krankenversicherungen (SDAT)"
  },
  {
    "code" : "SDAT_erheben_RV",
    "display" : "Erfassung Sozialversicherungsdaten von Rentenversicherungen (SDAT)"
  },
  {
    "code" : "SDAT_speichern_verarbeiten_KV",
    "display" : "Speicherung und Verarbeitung von codierten Sozialversicherungsdaten von Krankenversicherungen zu Zwecken med. Forschung innerhalb der verantwortlichen Stelle (SDAT)"
  },
  {
    "code" : "SDAT_speichern_verarbeiten_RV",
    "display" : "Speicherung und Verarbeitung von codierten Sozialversicherungsdaten von Rentenversicherungen zu Zwecken med. Forschung innerhalb der verantwortlichen Stelle (SDAT)"
  },
  {
    "code" : "SDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU_KV",
    "display" : "Bereitstellung umcodierter Sozialversicherungsdaten von Krankenversicherungen für wissenschaftliche Nutzung zu Zwecken med. Forschung an externe Forscher"
  },
  {
    "code" : "SDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU_RV",
    "display" : "Bereitstellung umcodierter Sozialversicherungsdaten von Rentenversicherungen für wissenschaftliche Nutzung zu Zwecken med. Forschung an externe Forscher"
  }]
}

```
