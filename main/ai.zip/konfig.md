# Konfiguration - v2025.2.0

