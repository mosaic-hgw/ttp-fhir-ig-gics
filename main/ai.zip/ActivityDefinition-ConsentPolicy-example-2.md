# Medizinische Daten nutzen - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "ActivityDefinition",
  "id" : "ConsentPolicy-example-2",
  "meta" : {
    "lastUpdated" : "2020-11-04T19:13:32.449+00:00",
    "profile" : ["https://ths-greifswald.de/fhir/StructureDefinition/gics/ActivityDefinition/ConsentPolicy"]
  },
  "extension" : [{
    "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/Created",
    "valueInstant" : "2020-01-02T04:05:06+01:00"
  }],
  "url" : "https://ths-greifswald.de/fhir/gics/ActivityDefinition/ConsentPolicy-example-2",
  "version" : "2025.2.0",
  "name" : "MDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU",
  "title" : "Medizinische Daten nutzen",
  "status" : "active",
  "date" : "2026-03-26T10:06:17+00:00",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [{
    "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ths-greifswald.de/"
    }]
  }],
  "description" : "Beispiel Consent Policy für die Nutzung medizinischer Daten im Rahmen eines Forschungsprojektes",
  "useContext" : [{
    "code" : {
      "system" : "http://terminology.hl7.org/CodeSystem/usage-context-type",
      "code" : "program"
    },
    "valueReference" : {
      "reference" : "d7a65ce8-2810-401a-b0db-70782a7b19a6"
    }
  }],
  "code" : {
    "coding" : [{
      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/Policy",
      "code" : "MDAT_wissenschaftlich_nutzen_EU_DSGVO_NIVEAU"
    }]
  }
}

```
