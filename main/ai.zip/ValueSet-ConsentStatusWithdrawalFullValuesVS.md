# ConsentStatusWithdrawalFullValues - v2026.1.0

 ![](assets/images/Design-Logo-THS-deutsch-271-padding.png) 

 
 2026.1.0 - ci-build  

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ConsentStatusWithdrawalFullValues**

## ValueSet: ConsentStatusWithdrawalFullValues 

| | |
| :--- | :--- |
| *Official URL*:https://ths-greifswald.de/fhir/ValueSet/gics/ConsentStatusWithdrawalFullValues | *Version*:2026.1.0 |
| Active as of 2025-06-12 | *Computable Name*:ConsentStatusWithdrawalFullValues |
| **Copyright/Legal**: Copyright 2020-2025 Unabhängige Treuhandstelle der Universitätsmedizin Greifswald | |

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ConsentStatusWithdrawalFullValuesVS",
  "url" : "https://ths-greifswald.de/fhir/ValueSet/gics/ConsentStatusWithdrawalFullValues",
  "version" : "2026.1.0",
  "name" : "ConsentStatusWithdrawalFullValues",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-06-12",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [{
    "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ths-greifswald.de/"
    }]
  }],
  "copyright" : "Copyright 2020-2025 Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "compose" : {
    "include" : [{
      "system" : "https://ths-greifswald.de/fhir/CodeSystem/gics/ConsentStatus",
      "concept" : [{
        "code" : "ACCEPTED"
      },
      {
        "code" : "WITHDRAWN"
      },
      {
        "code" : "NOT_ASKED"
      },
      {
        "code" : "NOT_CHOSEN"
      }]
    }]
  }
}

```
