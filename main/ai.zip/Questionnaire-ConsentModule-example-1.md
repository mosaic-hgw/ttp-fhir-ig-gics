# ConsentModule-example-1 - v2025.2.0



## Resource Content

```json
{
  "resourceType" : "Questionnaire",
  "id" : "ConsentModule-example-1",
  "meta" : {
    "extension" : [{
      "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/Created",
      "valueInstant" : "2020-01-02T04:05:06+01:00"
    }],
    "profile" : ["https://ths-greifswald.de/fhir/gics/StructureDefinition/ConsentModule"]
  },
  "language" : "de",
  "url" : "https://ths-greifswald.de/fhir/gics/Questionnaire/ConsentModule-example-1",
  "version" : "2025.2.0",
  "name" : "BIOMAT_erheben_lagern_nutzen",
  "status" : "draft",
  "date" : "2026-03-12T14:14:00+00:00",
  "publisher" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
  "contact" : [{
    "name" : "Unabhängige Treuhandstelle der Universitätsmedizin Greifswald",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.ths-greifswald.de/"
    }]
  }],
  "useContext" : [{
    "code" : {
      "system" : "http://fhir.de/ConsentManagement/CodeSystem/QuestionnaireComponents",
      "code" : "TemplateModule"
    },
    "valueReference" : {
      "reference" : "ResearchStudy/6048563-3f7f6-42f3-9752-fb6bd3feffc6"
    }
  }],
  "item" : [{
    "extension" : [{
      "url" : "http://hl7.org/fhir/StructureDefinition/designNote",
      "valueMarkdown" : "erheben, lagern, nutzen, eigentum übertragen, analysedaten zusammenführen"
    },
    {
      "id" : "36512b3f-994a-4010-b7d5-aac90a5b5b3a",
      "extension" : [{
        "url" : "reference",
        "valueReference" : {
          "reference" : "ActivityDefinition/b320c204-4b4e-4dd8-a11e-d29cc37d6535"
        }
      }],
      "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ConsentPolicyReference"
    },
    {
      "id" : "725f3ff0-4d31-42af-8e62-244cea523ec1",
      "extension" : [{
        "url" : "reference",
        "valueReference" : {
          "reference" : "ActivityDefinition/cf816922-e849-49f0-bc65-33a9e6f277ae"
        }
      }],
      "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ConsentPolicyReference"
    },
    {
      "id" : "f33a4ce5-f875-4f1b-838f-b90c51260246",
      "extension" : [{
        "url" : "reference",
        "valueReference" : {
          "reference" : "ActivityDefinition/e7f37956-eea7-41a4-8f8b-e268b522508b"
        }
      }],
      "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ConsentPolicyReference"
    },
    {
      "id" : "92f53938-0e96-4572-af94-23ea6a5db17d",
      "extension" : [{
        "url" : "reference",
        "valueReference" : {
          "reference" : "ActivityDefinition/ad258a43-1e03-42c4-b535-5c8c69ef2df2"
        }
      }],
      "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ConsentPolicyReference"
    },
    {
      "id" : "6250957d-ca69-4887-9f5a-1cb6e142bc95",
      "extension" : [{
        "url" : "reference",
        "valueReference" : {
          "reference" : "ActivityDefinition/a5f323ef-5915-4771-bba2-614ea0a600fb"
        }
      }],
      "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ConsentPolicyReference"
    },
    {
      "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/QuestionnaireLabel",
      "valueString" : "BIOMAT_erheben_lagern_nutzen"
    },
    {
      "extension" : [{
        "url" : "key",
        "valueString" : "mii_question_oid"
      },
      {
        "url" : "value",
        "valueString" : "2.16.840.1.113883.3.1937.777.24.5.3.18"
      }],
      "url" : "https://ths-greifswald.de/fhir/StructureDefinition/gics/ExternalProperty"
    }],
    "linkId" : "BIOMAT_erheben_lagern_nutzen|1.6",
    "_text" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/rendering-xhtml",
        "valueString" : "<div style=\"text-align: justify;\">Ich willige ein in die Gewinnung, Lagerung und wissenschaftliche Nutzung meiner <strong>Biomaterialien </strong>(Gewebe und Körperflüssigkeiten), wie in Punkt 3.1 bis 3.3 der Einwilligungserklärung und Punkt 3 der Patienteninformation beschrieben.</div>"
      }]
    },
    "type" : "choice"
  }]
}

```
